from main import Main


root = Main()
root.mainloop()

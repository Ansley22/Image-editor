from setuptools import setup

setup(
    app=["init.py"],
    setup_requires=["py2app"]
)

# simpleImageEditor

This repo has only the source code. Don't forget to add libraries.
